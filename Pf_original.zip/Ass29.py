#PF-Assgn-29
def calculate(distance,no_of_passengers):
    profit=0
    litres=distance/10
    price=70*litres
    profit+=(80*no_of_passengers)-price
    
    if 80*no_of_passengers > price:
        return profit
    else:
        return -1
    



#Provide different values for distance, no_of_passenger and test your program
distance=30
no_of_passengers=2
print(calculate(distance,no_of_passengers))
