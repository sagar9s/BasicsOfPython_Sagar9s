#PF-Assgn-33

def find_common_characters(msg1,msg2):
    s=''
    for i in msg1:
        for j in msg2:
            if i not in s and i !=' ' and i==j:
                s+=i
    return s if s else -1          
#    
msg1="Apple"
msg2="rstApp"

common_characters=find_common_characters(msg1,msg2)
print(common_characters)