#PF-Assgn-61
def validate_name(name):
    if len(str(name))>0 and len(str(name))<=15 and str(name).isalpha():
        return True
    else:
        return False

def validate_phone_no(phno):
    phno=str(phno)
    if len(str(phno))==10 and str(phno).isdigit() and len(set(phno))!=1:
        return True
    else:
        return False
def validate_email_id(email_id):
    str1="@"
    str2=".com"
    domain1="gmail.com"
    domain2="yahoo.com"
    domain3="hotmail.com"
    if str1 in email_id and email_id.count(str2)==1 and email_id.count(str1)==1 and (email_id.endswith(domain1) or email_id.endswith(domain2) or email_id.endswith(domain3)):
        return True
    else:
        return False
    
    
def validate_all(name,phone_no,email_id):
    if validate_name(name):
        if validate_phone_no(phone_no):
            if validate_email_id(email_id):
                print("All the details are valid")
            else:
                print("Invalid email id")
        else:
            print("Invalid phone number")       
    else:
        print("Invalid Name")
        
    


#Provide different values for name, phone_no and email_id and test your program
validate_all("Tina", "9999999999", "tina@yahoo.com")
