#PF-Assgn-48

def find_correct(word_dict):
    exact=0
    almost=0
    wrong=0
    lst=[]
    for k,v in word_dict.items():
        if len(k)==len(v):
            mismatch_count=len(list(filter(lambda i : k[i]!=v[i],range(0,len(k)))))                
            if mismatch_count==0:
                exact+=1
            elif mismatch_count<=2:
                almost+=1
            else:
                wrong+=1
        else:
            wrong+=1
    lst.append(exact)
    lst.append(almost)
    lst.append(wrong)
    
    return lst
                
                    
                    
                    

word_dict={'THREE': 'TRICE', 'MOST': 'MICE', 'GET': 'GOT', 'COME': 'COME'}
print(find_correct(word_dict))