#PF-Assgn-50

def sms_encoding(data):
    vowels=['a','e','i','o','u','A','E','I','O','U']
    lst=[]
    str1=""
    lst=data.split()
    for i in lst:
        if len(str(i))>1:
            for j in i:
                if j not in vowels:
                    str1+=j
            str1+=" "
        else:
            str1+=i
            str1+=" "
    return str1.strip()
    

data="MSD says I love cricket and tennis too"
print(sms_encoding(data))