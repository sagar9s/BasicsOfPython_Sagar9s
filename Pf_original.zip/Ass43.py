#PF-Assgn-43

def find_smallest_number(num):
    
    for i in range (1,1000):
        lst1=[]
        for j in range (1,i+1):
            if i%j==0:
                lst1.append(j)
                
        if len(lst1)==num:
            return i
            break
    

num=16
print("The number of divisors :",num)
result=find_smallest_number(num)
print("The smallest number having",num," divisors:",result)
