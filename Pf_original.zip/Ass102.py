#PF-Assgn-102
def list_rotate(uniquecode_list):
    rotated_list=[]


    for i in uniquecode_list:
        lst=[]
        lst1=[]
        lst3=[]
        lst4=[]
        for j in range(0,4):
            lst.append(i[j])
        for k in range(5,9):
            lst1.append(i[k])
    
        if len(str(i))==9 and str(i)[4]=="-":
            count=0
            for i in lst:
                
                if str(i).isalpha():
                    count+=1
        if count==2:
            m=""
            for i in lst:
                if not str(i).isdigit():
                    lst3.append(i)
            for i in lst1:
                m+=i
            m=m[1:]+m[0]
            m=m[1:]+m[0]
            lst3.append(m)
            str2=""
            for i in lst3:
                str2+=i
            rotated_list.append(str2)
        elif count==1:
            m=""
            for i in lst:
                if not str(i).isdigit():
                    lst4.append(i)
            for i in lst1:
                m+=i
            m=m[1:]+m[0]
            lst4.append(m)
            str3=""
            for i in lst4:
                str3+=i
            rotated_list.append(str3)
        else:
            continue
    return rotated_list

#You may modify the below code for testing
uniquecode_list=['K104-1212', 'G001-9889', 'U250-2365']
rotated_list = list_rotate(uniquecode_list)
print(rotated_list)