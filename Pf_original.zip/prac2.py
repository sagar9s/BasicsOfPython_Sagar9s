#PF-Assgn-102
def list_rotate(uniquecode_list):
    lst_o=[]
    lstX=[]
    lstY=[]
    for i in uniquecode_list:
        lstX.append(i[:4])
    for i in uniquecode_list:
        lstY.append(i[5:9])
    for i in lstX:
        cnt=0
        for j in i:
            if j.isalpha():
                cnt+=1
        if cnt==2:
            p=lstY[lstX.index(i)]
            s=p[-2:]+p[:-2]
            lst_o.append(lstX[lstX.index(i)][0:2]+str(s))
        if cnt==1:
            p=lstY[lstX.index(i)]
            s=p[-1:]+p[:-1]
            lst_o.append(lstX[lstX.index(i)][0:1]+str(s))
    #Write your code here
    return lst_o
uniquecode_list=['K104-1212', 'G001-9889', 'U250-2365']
