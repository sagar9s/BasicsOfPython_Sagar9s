#PF-Assgn-58
def validate_credit_card_number(card_number):
    card_number=str(card_number)

    lst=[]
    lst2=[]
    sum2=0
    sum3=0
    for i in range(0,len(str(card_number)),2):
        lst.append(2*int(card_number[i]))
    for i in lst:
        sum1=0
        if i>=10:
            sum1+=sum(map(int,str(i)))
            lst2.append(sum1)
        else:
            lst2.append(i)
    sum2+=sum(lst2)
    for i in range(1,len(str(card_number)),2):
        sum3+=int(card_number[i])
    sum3+=sum2   
    if sum3%10==0:
        result=True
    else:
        result=False  
    return result

card_number= 1456734512345698 #4539869650133101  #1456734512345698 # #5239512608615007
result=validate_credit_card_number(card_number)
if(result):
    print("credit card number is valid")
else:
    print("credit card number is invalid")
