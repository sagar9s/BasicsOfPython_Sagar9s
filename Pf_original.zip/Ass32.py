#PF-Assgn-32
def max_visited_speciality(patient_medical_speciality_list,medical_speciality):
    cP=0
    cE=0
    cO=0
    for i in patient_medical_speciality_list:
        if str(i).isalpha():
            if i=='P':
                cP+=1
            elif i=='E':
                cE+=1
            else:
                cO+=1
    if cP>cE and cP>cO:
        speciality="Pediatrics"
    elif cE>cP and cE>cO:
        speciality="ENT"   
    else:
        speciality="Orthopedics"

    return speciality

#provide different values in the list and test your program
patient_medical_speciality_list=[301,'P',302, 'P' ,305, 'P' ,401, 'E' ,656, 'E']
medical_speciality={"P":"Pediatrics","O":"Orthopedics","E":"ENT"}
speciality=max_visited_speciality(patient_medical_speciality_list,medical_speciality)
print(speciality)