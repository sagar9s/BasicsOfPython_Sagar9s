#PF-Tryout

#debug the below code
for i in range(0,5):
    for j in range(5,i,-1):
        print("*",end='')
    print("\r")