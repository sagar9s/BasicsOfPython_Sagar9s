#PF-Assgn-35

#Global variable
list_of_marks=(12,18,25,24,2,5,18,20,20,21)

def find_more_than_average():
    lst1=[]
    avg=sum(list_of_marks)/len(list_of_marks)
    for i in list_of_marks:
        if i>avg:
            lst1.append(i)
    perc=100*len(lst1)/len(list_of_marks)
    return perc
    #Remove pass and write your logic here

def sort_marks():
    return sorted(list_of_marks)

def generate_frequency():
    return list(map(lambda x: list_of_marks.count(x),list(range(0,26))))
    #Remove pass and write your logic here

print(find_more_than_average())
print(generate_frequency())
print(sort_marks())