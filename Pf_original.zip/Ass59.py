#PF-Assgn-59
def check_perfect_number(number):
    lst=[]
    for i in range(1,number):
        if number%i==0:
            lst.append(i)
    if sum(lst)==number:
        return True
    else:
        return False
    
def check_perfectno_from_list(no_list):
    lst2=[]
    for i in no_list:
        if check_perfect_number(i) and i!=0:
            lst2.append(i)
    
    return lst2
        
perfectno_list=check_perfectno_from_list([18,6,4,2,1,28,0])
print(perfectno_list)