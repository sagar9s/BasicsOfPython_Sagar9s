#PF-Assgn-28

def find_max(num1, num2):
    max_num=-1
    multiples=[15,30,45,60,75,90]
    if num2<15 or num1>90:
        return max_num
    else:
        for i in multiples:
            if i<=num2 and num1<i:
                max_num=i
    
        
    return max_num   
   

#Provide different values for num1 and num2 and test your program.
max_num=find_max(24,29)
print(max_num)