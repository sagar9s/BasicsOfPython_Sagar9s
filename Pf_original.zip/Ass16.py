#PF-Assgn-16
def make_amount(rupees_to_make,no_of_five,no_of_one):
    five_needed=0
    one_needed=0
    
    actual_five_needed=rupees_to_make//5

    if actual_five_needed>=no_of_five:
        five_needed=no_of_five
        one_needed=rupees_to_make-(five_needed)*5
        if one_needed>no_of_one:
            print(-1)
        else:
            print("No. of Five needed :", five_needed)
            print("No. of One needed  :", one_needed)
        
        
    else:
        five_needed=actual_five_needed
        one_needed=rupees_to_make-(five_needed)*5
        if one_needed>no_of_one:
            print(-1)
        else:
            print("No. of Five needed :", five_needed)
            print("No. of One needed  :", one_needed)


make_amount(28,8,5)
