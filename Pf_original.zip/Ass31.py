#PF-Assgn-31
def check_palindrome(word):
    status=False
    rev=word[::-1]
    if rev==word:
        status=True
    return status
    
    #Remove pass and write your logic here

status=check_palindrome("malayalam")

if(status):
    print("word is palindrome")
else:
    print("word is not palindrome")