#PF-Assgn-38

def check_double(number):
    dub=2*number
    number=str(number)
    dub=str(dub)
    if len(dub)==len(number):
        for i in number:
            if i not in dub:
                return False
    
        return True       
    
    else:
        return False
        
print(check_double(106))
