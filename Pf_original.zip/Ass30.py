#PF-Assgn-30

def encode(message):
    str1=""
    lst=[]
    if len(message)==1:
        return str(len(message))+message

    for i in str(message):
        lst.append(i)
    length=len(lst)
    count1=1
    for i in range(0,length-1):
        if lst[i]==lst[i+1]:
            count1+=1
        else:
            str1+=str(count1)+str(lst[i])
            count1=1
    str1+=str(count1)+str(lst[i+1])
    return str1
        
            
encoded_message=encode("ababaaab")
print(encoded_message)