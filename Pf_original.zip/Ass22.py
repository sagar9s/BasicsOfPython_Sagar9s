#PF-Assgn-22
def find_leap_years(given_year):

    # Write your logic here
    list_of_leap_years=[]
    for y in range(given_year,given_year+61):
        if y%4==0 and (y %100!=0 or y%400==0):
            list_of_leap_years.append(y)
        if len(list_of_leap_years)==15:
            break
    return list_of_leap_years

list_of_leap_years=find_leap_years(1996)
print(list_of_leap_years)
