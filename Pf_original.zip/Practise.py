#PF-Assgn-102
def list_rotate(uniquecode_list):
    lst_o=[]
    lstx=[]
    lsty=[]
    for i in uniquecode_list:
        lstx.append(i[:4])
    for i in uniquecode_list:
        lsty.append(i[5:9])
    for i in lstx:
        cnt=0
        for j in i:
            if j.isalpha():
                cnt+=1
        if cnt==2:
            p=lsty[lstx.index(i)]
            s=p[-2:]+p[:-2]
            lst_o.append(lstx[lstx.index(i)][0:2]+str(s))
        if cnt==1:
            p=lsty[lstx.index(i)]
            s=p[1:]+p[0]
            lst_o.append(lstx[lstx.index(i)][0:1]+str(s))
    #Write your code here
    return lst_o
uniquecode_list=['K104-1212', 'G001-9889', 'U250-2365']
rotated_list = list_rotate(uniquecode_list)
print(rotated_list)
