#PF-Assgn-44

def find_duplicates(list_of_numbers):
    lst=[]
    lst1=[]
    lst2=[]
    for i in list_of_numbers:
        if list_of_numbers.count(i)>1:
            lst.append(i)
            lst1=set(lst)
    if len(lst1)>=1:
        return list(lst1)
    else:
        return lst2

list_of_numbers=[-1,0,1,2,3]
list_of_duplicates=find_duplicates(list_of_numbers)
print(list_of_duplicates)