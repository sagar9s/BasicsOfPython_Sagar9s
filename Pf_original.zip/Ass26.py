#PF-Assgn-26

def solve(heads,legs):
    error_msg="No solution"
    chicken_count=0
    rabbit_count=0

    if legs<heads or legs%2!=0:
        print(error_msg)
    else:
        for rabbit_count in range(heads+1):
            chicken_count=heads-rabbit_count
            if 2*chicken_count+4*rabbit_count==legs:
                print(chicken_count,rabbit_count)
solve(38,131)
