#PF-Assgn-57
def check_prime(number):
    
    x = True 
    for i in range(2, number):
        if number%i == 0:
            x = False
            break 
    if x:
        return True
    else:
        return False

def rotations(num):
    lst=[]
    
    
    count=0
    m=str(num)
    lst.append(num)
    while(count<len(str(num))-1):
        m=m[1:]+m[0]
        lst.append(int(m))
        count+=1
    return lst
        
def get_circular_prime_count(limit):
    count=0
    for i in range(2,limit):
        if check_prime(i):
            rot_list=rotations(i)
            for j in rot_list:
                if not check_prime(j):
                    break
            else:
                count+=1   

    return count
             
print(get_circular_prime_count(100))