#PF-Assgn-40
def is_palindrome(word):
    word1=word.lower()
    if word1==word1[::-1]:
        return True
    else:
        return False
result=is_palindrome("Madam")
if(result):
    print("The given word is a Palindrome")
else:
    print("The given word is not a Palindrome")
