#PF-Assgn-60
def remove_duplicates(value):
    return "".join(sorted(set(value),key=value.index,reverse=False))

print(remove_duplicates("11223445566666ababzzz@@@123#*#*"))
