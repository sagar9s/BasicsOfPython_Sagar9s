#PF-Assgn-47
def encrypt_sentence(sentence):
    lst1=[]
    lst2=[]
    
    
    vowels=['a','e','i','o','u','A','E','I','O','U']
    str1=""
    lst1=sentence.split()
    for i in lst1:
        if lst1.index(i)%2==0:
            j=str(i[::-1])
            lst2.append(j)
        else:
            str2=""
            str3=""
            for k in i:
                if k not in vowels:
                    str2+=k
                elif k in vowels:
                    str3+=k          
                else:
                    continue
            str2+=str3
            lst2.append(str2)
                    
    for i in lst2:
        str1+=i
        str1+=" "
    return str1.strip()
sentence="good day"
encrypted_sentence=encrypt_sentence(sentence)
print(encrypted_sentence)
