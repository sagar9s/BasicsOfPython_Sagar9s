#PF-Assgn-36
def create_largest_number(number_list):
    str1=""
    number_list.sort()
    length=len(number_list)
    for i in range(length-1,-1,-1):
        str1+=str(number_list[i])
    return int(str1)

number_list=[98,22,10]
largest_number=create_largest_number(number_list)
print(largest_number)