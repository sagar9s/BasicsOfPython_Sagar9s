#PF-Assgn-15

def find_product(num1,num2,num3):
    product=1
    #write your logic here
    num=[num1,num2,num3]

    if (num[0]==7):
        product*=num[1]*num[2]
    elif(num[1]==7):
        product*=num[2]
    elif(num[2]==7):
        product=-1
    else:
        product*=num[0]*num[1]*num[2]
    
    return product

#Provide different values for num1, num2, num3 and test your program
product=find_product(7,6,2)
print(product)

