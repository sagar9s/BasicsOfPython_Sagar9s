#PF-Assgn-46

def nearest_palindrome(number):
    num=number
    if len(str(number))<2:
        return number+1
    else:
        while not isPalindrome(number):
            number+=1
        if number>num:
            return number
        else:
            return nearest_palindrome(number+1)
def isPalindrome(number):
    rev=""
    number=str(number)
    rev+=number[::-1]
    
    if rev==number:
        return True
    else:
        return False
    
        
number=12300
print(nearest_palindrome(number))